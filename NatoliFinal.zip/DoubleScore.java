public class DoubleScore extends NatoliSlot
{
	private double num;


		public DoubleScore(int value, int value2, int value3)
		{
			super(value,value2,value3);

		}

		public double setNum(double total)
		{
			if (super.getValue()== 1 && super.getValue2()==1 && super.getValue3()==1)
			{
				num = Math.pow(total, 3);
			}

				else if(super.getValue() == 2 && super.getValue2() ==2 && super.getValue3() == 2)
				{
					num = Math.pow(total, 3);
				}


					else if(super.getValue()==3 && super.getValue2() ==3 && super.getValue3()==3)
					{
						num = Math.pow(total, 3);
					}

			if(super.getValue() ==1 && super.getValue2() ==1 && super.getValue3() == 2)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==1 && super.getValue2() ==1 && super.getValue3() == 3)
				{
					num = Math.pow(total, 2);
				}

			if(super.getValue() ==1 && super.getValue3() ==1 && super.getValue2()== 2)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue()==1 && super.getValue3() ==1 && super.getValue2() == 3)
				{
					num = Math.pow(total, 2);
				}


			if(super.getValue2() ==1 && super.getValue3() ==1 && super.getValue() == 2)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue2() ==1 &&super.getValue3() ==1 && super.getValue()== 3)
				{
					num = Math.pow(total, 2);
				}

					if(super.getValue2() ==1 &&super.getValue3() ==4 && super.getValue()== 2)
					{
						num = Math.pow(total, 2);
					}

						else if(super.getValue2() ==1 &&super.getValue3() ==4 && super.getValue()== 3)
						{
							num = Math.pow(total, 2);
						}
			if(super.getValue() ==2 && super.getValue2()==2 && super.getValue3() ==1)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==2 && super.getValue2()==2 && super.getValue3() == 3)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue() ==2 && super.getValue3() ==2 && super.getValue2() == 1)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==2 && super.getValue3() ==2 && super.getValue2() == 3)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue2() ==2 && super.getValue3() ==2 && super.getValue() == 3)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue2()==2 && super.getValue3() ==2 && super.getValue()==1)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue() ==3 && super.getValue2() ==3 && super.getValue3() == 1)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==3 && super.getValue2() ==3 && super.getValue3() == 2)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue() ==3 && super.getValue3() ==3 && super.getValue2() == 1)
			{
					num = Math.pow(total, 2);
			}
				else if(super.getValue() ==3 && super.getValue3() ==3 && super.getValue2()== 2)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue2() ==3 && super.getValue3()==3 && super.getValue()== 1)
			{
				num = Math.pow(total, 2);
			}
				if(super.getValue2() ==3 && super.getValue3()==3 && super.getValue() == 2)
				{
						num = Math.pow(total, 2);
				}

		return num;

	}

}