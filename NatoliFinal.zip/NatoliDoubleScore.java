/**
Author: Craig Natoli
Purpose: Create a slot machine that doubles the number entered if 2 pictures match up, triples
the number if 3 pictures match up, or reset back to 0 if none of the pictures match up.
Date Created:5/9/2017
*/
public class NatoliDoubleScore extends NatoliSlot
{
	private double num;

		//@parm value, value2, value3
		public NatoliDoubleScore(int value, int value2, int value3)
		{
			//@parm value,value2,value3 in super
			super(value,value2,value3);

		}
		//@parm total in setNum method
		public double setNum(double total)
		{
			//@parm super methods getValue(), getValue2(), getValue3()
			if (super.getValue()== 1 && super.getValue2()==1 && super.getValue3()==1)
			{
				num = Math.pow(total, 3);
			}

				else if(super.getValue() == 2 && super.getValue2() ==2 && super.getValue3() == 2)
				{
					num = Math.pow(total, 3);
				}


					else if(super.getValue()==3 && super.getValue2() ==3 && super.getValue3()==3)
					{
						num = Math.pow(total, 3);
					}

			if(super.getValue() ==1 && super.getValue2() ==1 && super.getValue3() == 2)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==1 && super.getValue2() ==1 && super.getValue3() == 3)
				{
					num = Math.pow(total, 2);
				}

			if(super.getValue() ==1 && super.getValue3() ==1 && super.getValue2()== 2)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue()==1 && super.getValue3() ==1 && super.getValue2() == 3)
				{
					num = Math.pow(total, 2);
				}


			if(super.getValue2() ==1 && super.getValue3() ==1 && super.getValue() == 2)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue2() ==1 &&super.getValue3() ==1 && super.getValue()== 3)
				{
					num = Math.pow(total, 2);
				}

					if(super.getValue2() ==1 &&super.getValue3() ==4 && super.getValue()== 2)
					{
						num = Math.pow(total, 2);
					}

						else if(super.getValue2() ==1 &&super.getValue3() ==4 && super.getValue()== 3)
						{
							num = Math.pow(total, 2);
						}
			if(super.getValue() ==2 && super.getValue2()==2 && super.getValue3() ==1)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==2 && super.getValue2()==2 && super.getValue3() == 3)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue() ==2 && super.getValue3() ==2 && super.getValue2() == 1)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==2 && super.getValue3() ==2 && super.getValue2() == 3)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue2() ==2 && super.getValue3() ==2 && super.getValue() == 3)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue2()==2 && super.getValue3() ==2 && super.getValue()==1)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue() ==3 && super.getValue2() ==3 && super.getValue3() == 1)
			{
				num = Math.pow(total, 2);
			}
				else if(super.getValue() ==3 && super.getValue2() ==3 && super.getValue3() == 2)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue() ==3 && super.getValue3() ==3 && super.getValue2() == 1)
			{
					num = Math.pow(total, 2);
			}
				else if(super.getValue() ==3 && super.getValue3() ==3 && super.getValue2()== 2)
				{
					num = Math.pow(total, 2);
				}
			if(super.getValue2() ==3 && super.getValue3()==3 && super.getValue()== 1)
			{
				num = Math.pow(total, 2);
			}
				if(super.getValue2() ==3 && super.getValue3()==3 && super.getValue() == 2)
				{
						num = Math.pow(total, 2);
				}

		return num;//@ return num

	}// end of setNum method

}// end of class