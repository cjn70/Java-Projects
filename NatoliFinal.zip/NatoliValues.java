/**
Author: Craig Natoli
Purpose: Create a slot machine that doubles the number entered if 2 pictures match up, triples
the number if 3 pictures match up, or reset back to 0 if none of the pictures match up.
Date Created:5/9/2017
*/
public interface NatoliValues
{
	String getNum1(int value);
	String getNum2(int value2);
	String getNum3(int value3);
}// end of interface