/**
Author: Craig Natoli
Purpose: Create a slot machine that doubles the number entered if 2 pictures match up, triples
the number if 3 pictures match up, or reset back to 0 if none of the pictures match up.
Date Created:5/9/2017
*/
public class NatoligetPictures implements NatoliValues
{
	private String Num1;
	private String Num2;
	private String Num3;

	public NatoligetPictures()
	{

	}

	public String getNum1(int value)//@parm value
	{
		switch(value)//@parm value
		{
			case 1:
			 Num1 = "cherry1.jpg";

			break;

			case 2:

			Num1 = "lemon1.png";

			break;

			case 3:

			Num1 = "watermelon1.jpg";

			break;

		}// end of switch

		return Num1;//@return NUm1
	}// end of getNum1

	//@parm value2
	public String getNum2(int value2)
	{
		switch(value2)//@parm value2
		{
			case 1:
			 Num2 = "cherry1.jpg";

			break;

			case 2:

			Num2 = "lemon1.png";

			break;

			case 3:

			Num2 = "watermelon1.jpg";

			break;

		}//end of switch

		return Num2;//@return Num2
	}// end of getNum2

	//@parm value3
	public String getNum3(int value3)
	{
		switch(value3)//@parm value3
		{
			case 1:

			 Num3 = "cherry1.jpg";

			break;

			case 2:

			Num3 = "lemon1.png";

			break;

			case 3:

			Num3 = "watermelon1.jpg";

			break;


		}// end of switch
		return Num3;//@return Num3
	}// end of getNum3
}// end of class