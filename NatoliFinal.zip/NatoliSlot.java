/**
Author: Craig Natoli
Purpose: Create a slot machine that doubles the number entered if 2 pictures match up, triples
the number if 3 pictures match up, or reset back to 0 if none of the pictures match up.
Date Created:5/9/2017
*/
import java.util.Random;
public class NatoliSlot
{
	private int sides =3;
	private int value;
	 private int value2;
	 private int value3;

	//@parm Value, Value2, Value3 in NatoliSlot
    public NatoliSlot(int Value, int Value2, int Value3)
	{
		Value = value;
		Value2 = value2;
		Value3 = value3;

		roll();


	}// end of NatoliSlot method
// Storing sides into value
	public  void roll()
	{
		Random rand = new Random();
		value = rand.nextInt(sides)+1;
		value2 = rand.nextInt(sides)+1;
		value3 = rand.nextInt(sides)+1;


	}//end of roll method

	public void setvalue(int Value)//@parm Value
	{
		value = Value;
	}//end of setvalue method

	public void setvalue2(int Value2)//@parm Value2
	{
		value2 = Value2;
	}//end of setValue2

	public void setvalue3(int Value3)//@parm Value3
	{
		value3 = Value3;
	}//end of setvalue3

	public int getValue()
	{
		return  value;//@return value
	}//end of getValue

	public int getValue2()
	{
		return  value2;//@retrun value
	}// end of getValue2

	public int getValue3()
	{
		return  value3;//@return value
	}//end of getValue3



}//End of class